import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class example02_bit_check extends PApplet {

// Example 2 -- Bit check pattern
public void setup() {
  size(512, 512);
  println(width);
  println(height);
}

public void draw() {
  for (int y = 0; y < width; y++) {
    for (int x = 0; x < height; x++) {
      int c; // = color(x*y & 0xFF);
     
      if (((x*y) & 64) == 64)
      {
        c = color(32, 32, 255);
      } else {
       c = color(32, 32, 128);
      }
      set(x, y, c);
    }
  }
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "example02_bit_check" });
  }
}
