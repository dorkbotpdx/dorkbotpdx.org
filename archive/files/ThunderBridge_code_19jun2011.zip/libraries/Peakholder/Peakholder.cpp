/* Library for Peakholder Circuit - Interfacing Percussion Sensors
 * http://www.pjrc.com/peakholder/
 * Copyright (c) 2011 PJRC.COM, LLC - Paul Stoffregen <paul@pjrc.com>
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include "hardware.h"
#include "Peakholder.h"
#include "wiring.h"
#include <avr/pgmspace.h>

PeakholderClass Peakholder;

static uint8_t num_channels=4;
static uint8_t current_channel;
static uint8_t peak_threshold=10;
static uint16_t clear_period;
static uint8_t history_length;
static uint16_t sample[PEAKHOLDER_MAX_CHANNELS * PEAKHOLDER_MAX_HISTORY_LEN];
static uint16_t clear_timer[PEAKHOLDER_MAX_CHANNELS];

static volatile uint8_t buffer_channel[PEAKHOLDER_BUFFER_LEN];
static volatile uint16_t buffer_value[PEAKHOLDER_BUFFER_LEN];
static volatile uint8_t buffer_head;
static volatile uint8_t buffer_tail;


void PeakholderClass::begin(uint8_t numberOfChannels)
{
	if (numberOfChannels > PEAKHOLDER_MAX_CHANNELS) {
		numberOfChannels = PEAKHOLDER_MAX_CHANNELS;
	} else if (numberOfChannels == 0) {
		numberOfChannels = 1;
	}
	num_channels = numberOfChannels;
	buffer_head = 0;
	buffer_tail = 0;
	memset(sample, 0, sizeof(sample));
	memset(clear_timer, 0, sizeof(clear_timer));
	current_channel = 0;
	setLatency(5);
	setZeroPeriod(30);
	PEAKHOLDER_ADC_START(numberOfChannels);
}

void PeakholderClass::setLatency(uint8_t latency_milliseconds)
{
	uint32_t n = (uint32_t)(latency_milliseconds) << 16;
	n /= ((uint32_t)(PEAKHOLDER_SAMPLE_TIME_MS * 65536.0) * num_channels);
	n++;
	if (n > PEAKHOLDER_MAX_HISTORY_LEN) n = PEAKHOLDER_MAX_HISTORY_LEN;
	history_length = n;
}

void PeakholderClass::setZeroPeriod(uint8_t period_milliseconds)
{
	uint32_t n = (uint32_t)period_milliseconds << 16;
	n /= ((uint32_t)(PEAKHOLDER_SAMPLE_TIME_MS * 65536.0) * num_channels);
	clear_period = n + 1;
}

void PeakholderClass::setThreshold(uint16_t threshold)
{
	peak_threshold = threshold;
}


ISR(ADC_vect)
{
	uint8_t msb, lsb, i, ch;
	uint8_t next_channel, next_next_channel;
	uint16_t *hist, *p;
	uint16_t t, peak_value=0;
	uint8_t peak_location=0;
	int16_t slope;

	// read the value as quickly as possible
	lsb = ADCL;
	msb = ADCH;
	// the next conversion is already underway... but we
	// need to set the mux up for the following conversion
	ch = current_channel;
	next_channel = ch + 1;
	if (next_channel >= num_channels) next_channel = 0;
	current_channel = next_channel;
	next_next_channel = next_channel + 1;
	if (next_next_channel >= num_channels) next_next_channel = 0;
	PEAKHOLDER_ADC_MUX_CHANNEL(next_next_channel);
	// is this channel in clear-to-zero mode?
	t = clear_timer[ch];
	if (t > 0) {
		// ignore ADC during clear to zero mode
		t = t - 1;
		clear_timer[ch] = t;
		if (t == 0) {
			// exit clear-to-zero mode
			pinMode(PEAKHOLDER_CHANNEL_TO_PIN(ch), INPUT);
		}
	} else {
		// store this reading into the sample history.
		hist = &sample[ch * PEAKHOLDER_MAX_HISTORY_LEN];
		memmove(hist + 1, hist, (history_length - 1) * 2);
		hist[0] = ((msb << 8) | lsb);
		// find the peak, and its position
		for (i=0, p=hist; i<history_length; i++, p++) {
			if (*p >= peak_value) {
				peak_value = *p;
				peak_location = i;
			}
		}
		// is the peak substantial, and at the end of the history?
		if (peak_value >= peak_threshold && peak_location == history_length-1) {
			// drive the channel to zero volts
			pinMode(PEAKHOLDER_CHANNEL_TO_PIN(ch), OUTPUT);
			digitalWrite(PEAKHOLDER_CHANNEL_TO_PIN(ch), LOW);
			// zero all stored history
			for (i=0, p=hist; i<history_length; i++) {
				*p++ = 0;
			}
			// set the clear timer to keep this channel zero
			clear_timer[ch] = clear_period;
			// send this peak to the user application
			i = buffer_head + 1;
			if (i >= PEAKHOLDER_BUFFER_LEN) i = 0;
			if (i != buffer_tail) {
				buffer_value[i] = peak_value;
				buffer_channel[i] = ch;
				buffer_head = i;
			}
		}
	}
}

uint8_t PeakholderClass::available(void)
{
	uint8_t head, tail;

	head = buffer_head;
	tail = buffer_tail;
	if (head >= tail) return head - tail;
	return PEAKHOLDER_BUFFER_LEN + head - tail;
}

uint8_t PeakholderClass::getInputNumber(void)
{
	uint8_t tail;

	tail = buffer_tail + 1;
	if (tail >= PEAKHOLDER_BUFFER_LEN) tail = 0;
	return buffer_channel[tail];
}

uint16_t PeakholderClass::readValue(void)
{
	uint8_t head, tail;
	uint16_t value;

	head = buffer_head;
	tail = buffer_tail;
	if (head == tail) return 0;
	tail = tail + 1;
	if (tail >= PEAKHOLDER_BUFFER_LEN) tail = 0;
	value = buffer_value[tail];
	buffer_tail = tail;
	return value;
}

// Convert 10 bit linear measurements to a logarthmic scale
// suitable for sending as MIDI velocity numbers.  The
// "range" parameter should be probably be between 30 to 60,
// with 36 probably a good default.
//
// This function uses fast 16 bit unsigned integer math.  :-)
//
uint8_t PeakholderClass::analog2velocity(uint16_t val, uint8_t range)
{
#if 0
	if (val == 0) return 0;
	float scale = 1.0 + (20.0 / (float)range) * log10((float)val / 1023.0);
	if (scale < 0) return 0;
	return 127 * scale;
#else
	uint8_t i, e, b;
	uint16_t s=0;
	static const uint8_t PROGMEM table[] = {225,124,65,34,17,9,4,2,1};

	if (val == 0) return 0;
	if (val >= 1023) return 127;
	for (e=0; (val & 512) == 0; e++) val <<= 1;
	for (i=0; i<9; i++) {  // cordic algorithm
		uint16_t x = val + (val >> (i + 1));
		if (x < 1024) {
			val = x;
			s += pgm_read_byte(table + i);
		}
	}
	s += e * 385;
	s <<= 4;
	s += (range >> 1);
	s /= range;
	if (s >= 1024) return 0;
	s = 1024 - s;
	if (s > 511) {
		s -= 512;
		b = 64;
	} else if (s > 255) {
		s -= 256;
		b = 32;
	} else {
		b = 0;
	}
	return b + ((s * 127) >> 10);
#endif
}

const char * PeakholderClass::version(void)
{
	return PEAKHOLDER_VERSION;
}


