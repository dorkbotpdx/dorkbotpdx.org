/* Hardware definitions for A/D converter on numerous Arduino compatible boards
 * Written by Paul Stoffregen <paul@pjrc.com>, 2011
 * 
 * This file is released into the public domain.  No copyright is claimed.
 * 
 * Information in ths file is primarily factual, rather than expression which
 * could properly be the subject of copyright.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include <stdint.h>
#include <string.h>
#include <avr/io.h>
#include <avr/interrupt.h>

/************************************************/
/*  Board specific configuration                */ 
/************************************************/

// Arduino Uno, Duemilanove, Diecimila, Nano, Lilypad, etc
// http://www.arduino.cc/en/Main/ArduinoBoardUno
// http://www.arduino.cc/en/Main/ArduinoBoardDuemilanove
#if defined(__AVR_ATmega328P__) || defined(__AVR_ATmega168__) || defined(__AVR_ATmega8__)
#define PEAKHOLDER_MAX_CHANNELS		6
#define PEAKHOLDER_CHANNEL_TO_PIN(ch)	(14 + (ch))
//  Note: The 2 extra analog on Nano, Fio, and Mini can't be
//  used because they do not have a corresponding digital pin.
//  To work around this, connect a digital pin to each, and
//  modify PEAKHOLDER_CHANNEL_TO_PIN() to return those pins.

// Arduino Mega (untested)
// http://arduino.cc/en/Main/ArduinoBoardMega2560
#elif defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__)
#define PEAKHOLDER_MAX_CHANNELS		16
#define PEAKHOLDER_ADC_MUX_CHANNEL(ch)	(ADMUX = 0xC0 | ((ch) & 0x07), ADCSRB = (ADCSRB & ~(1 << MUX5)) | ((((ch) >> 3) & 0x01) << MUX5))
#define PEAKHOLDER_CHANNEL_TO_PIN(ch)	(54 + (ch))

// Teensy++ 2.0 or 1.0
// http://www.pjrc.com/teensy/pinout.html
#elif defined(__AVR_AT90USB646__) || defined(__AVR_AT90USB1286__)
#define PEAKHOLDER_MAX_CHANNELS		8
#define PEAKHOLDER_CHANNEL_TO_PIN(ch)	(38 + (ch))

// Teensy 2.0
// http://www.pjrc.com/teensy/pinout.html
#elif defined(__AVR_ATmega32U4__)
#define PEAKHOLDER_MAX_CHANNELS		12	
#define PEAKHOLDER_ADC_MUX_CHANNEL(ch)	if ((ch) < 6) { ADMUX = 0xC0 | (((ch) < 2) ? (ch) : (ch) + 2); ADCSRB = 0; } else { ADMUX = 0xC0 | (11 - (ch)); ADCSRB = 0x20; }
#define PEAKHOLDER_CHANNEL_TO_PIN(ch)	((ch) <= 10 ? 21 - (ch) : 22)

// Wiring (untested)
// http://wiring.org.co/hardware/
#elif defined(__AVR_ATmega128__) || defined(__AVR_ATmega1281__) || (__AVR_ATmega2561__)
#define PEAKHOLDER_MAX_CHANNELS         8
#define PEAKHOLDER_CHANNEL_TO_PIN(ch)	(40 + (ch))

// Sanguino (untested)
// http://sanguino.cc/hardware
#elif defined(__AVR_ATmega644__) || defined(__AVR_ATmega644P__)
#define PEAKHOLDER_MAX_CHANNELS		8
#define PEAKHOLDER_CHANNEL_TO_PIN(ch)	(31 - (ch))

// Gator (untested)
// http://ruggedcircuits.com/html/arduino.html
#elif defined(__AVR_ATmega324P__)
#define PEAKHOLDER_MAX_CHANNELS		8
#define PEAKHOLDER_CHANNEL_TO_PIN(ch)	(14 + (ch))

// Liquidware Illuminato (untested)
// http://www.liquidware.com/wikipages/name/Illuminato
#elif defined(__AVR_ATmega645__)
#define PEAKHOLDER_MAX_CHANNELS		6
#define PEAKHOLDER_CHANNEL_TO_PIN(ch)	(36 + (ch))

// Boston Android EVAL-USB-2561 (untested)
// http://www.bostonandroid.com/EVAL-USB-2561.html
#elif defined(__AVR_ATmega2561__)
#define PEAKHOLDER_MAX_CHANNELS		8
#define PEAKHOLDER_CHANNEL_TO_PIN(ch)	(ch)

// AVR Butterfly (untested)
#elif defined(__AVR_ATmega169__)
#define PEAKHOLDER_MAX_CHANNELS		8
#define PEAKHOLDER_CHANNEL_TO_PIN(ch)	(40 + (ch))

// arduino-tiny, ATtiny84 (untested)
// http://code.google.com/p/arduino-tiny/
#elif defined(__AVR_ATtinyX4__)
#define PEAKHOLDER_MAX_CHANNELS		8
#define PEAKHOLDER_ADC_MUX_CHANNEL(ch)	(ADMUX = 0x80 | ((ch) & 0x07)) // Vref=1.1V
#define PEAKHOLDER_CHANNEL_TO_PIN(ch)	(10 - (ch))

// arduino-tiny, ATtiny85 (untested)
// http://code.google.com/p/arduino-tiny/
// http://hlt.media.mit.edu/wiki/pmwiki.php?n=Main.ArduinoATtiny4585
#elif defined(__AVR_ATtinyX5__)
#define PEAKHOLDER_MAX_CHANNELS		4
#define PEAKHOLDER_ADC_MUX_CHANNEL(ch)	(ADMUX = 0x90 | ((ch) & 0x03)) // Vref=2.56V
#define PEAKHOLDER_CHANNEL_TO_PIN(ch)	((ch) == 0 ? 5 : ((ch) == 1 ? 2 : ((ch) == 2 ? 4 : 3))) 

// Unknown Hardware
#else
#error "This hardware is unknown, please edit me with hardware details
#endif


/************************************************/
/*  Defaults - Used only if not defined above   */
/************************************************/

// A buffer of 14 samples is a good default, allowing enough time to capture any
// peak, even if only a only 4 channels are used and the A/D runs fast.  But if
// memory is tight, this might be reduced, or if only 1 or 2 channels are to be
// used, this might need to increase.
#ifndef PEAKHOLDER_MAX_HISTORY_LEN
#define PEAKHOLDER_MAX_HISTORY_LEN	14
#endif

// In theory, all inputs could detect a peak before the main program can
// read then, so a worst case buffer is the most cautious approach.  This
// can be reduced if memory is limited.
#ifndef PEAKHOLDER_BUFFER_LEN
#define PEAKHOLDER_BUFFER_LEN		PEAKHOLDER_MAX_CHANNELS + 2
#endif

// Nearly all AVR A/D converters need a 100 to 200 kHz clock
// which is divided from F_CPU by a 2 to 128 prescaler
#if !defined(PEAKHOLDER_ADC_PRESCALE) && !defined(PEAKHOLDER_ADC_PRESCALE_BITS)
#if F_CPU > 12800000
  #define PEAKHOLDER_ADC_PRESCALE	128
  #define PEAKHOLDER_ADC_PRESCALE_BITS	7
#elif F_CPU > 6400000
  #define PEAKHOLDER_ADC_PRESCALE	64
  #define PEAKHOLDER_ADC_PRESCALE_BITS	6
#elif F_CPU > 3200000
  #define PEAKHOLDER_ADC_PRESCALE	32
  #define PEAKHOLDER_ADC_PRESCALE_BITS	5
#elif F_CPU > 1600000
  #define PEAKHOLDER_ADC_PRESCALE	16
  #define PEAKHOLDER_ADC_PRESCALE_BITS	4
#elif F_CPU > 800000
  #define PEAKHOLDER_ADC_PRESCALE	8
  #define PEAKHOLDER_ADC_PRESCALE_BITS	3
#elif F_CPU > 400000
  #define PEAKHOLDER_ADC_PRESCALE	4
  #define PEAKHOLDER_ADC_PRESCALE_BITS	2
#else
  #define PEAKHOLDER_ADC_PRESCALE	2
  #define PEAKHOLDER_ADC_PRESCALE_BITS	1
#endif
#endif

// Nearly all AVR A/D converters are 13.5 A/D clocks per conversion in free running mode
#ifndef PEAKHOLDER_SAMPLE_TIME_MS
#define PEAKHOLDER_SAMPLE_TIME_MS	1000.0 / (double)(F_CPU / (PEAKHOLDER_ADC_PRESCALE * 13.5))
#endif

// Most AVR with 8 or fewer analog inputs have a simple ADMUX register
#ifndef PEAKHOLDER_ADC_MUX_CHANNEL
#define PEAKHOLDER_ADC_MUX_CHANNEL(ch)	(ADMUX = 0xC0 | ((ch) & 0x07))
#endif

// This code works on nearly all AVR A/D converters, using the macros above.  However,
// if a board needs special A/D initialization, if can define this function.
#ifndef PEAKHOLDER_ADC_START
static inline void PEAKHOLDER_ADC_START(uint8_t) __attribute__((always_inline, unused));
static inline void PEAKHOLDER_ADC_START(uint8_t num_channels)
{
	PEAKHOLDER_ADC_MUX_CHANNEL(0);
	ADCSRB = 0;
	cli();
	ADCSRA = (1<<ADEN)|(1<<ADSC)|(1<<ADATE)|(1<<ADIF)|(1<<ADIE)|PEAKHOLDER_ADC_PRESCALE_BITS;
	if (num_channels > 1) PEAKHOLDER_ADC_MUX_CHANNEL(1);
	sei();
}
#endif


