/* Library for Peakholder Circuit - Interfacing Percussion Sensors
 * http://www.pjrc.com/peakholder/
 * Copyright (c) 2011 PJRC.COM, LLC - Paul Stoffregen <paul@pjrc.com>
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include <stdint.h>

#define PEAKHOLDER_VERSION  "0.2"

class PeakholderClass {
public:
	static void begin(uint8_t numberOfChannels);
	static void setThreshold(uint16_t threshold);
	static void setLatency(uint8_t latency_milliseconds);
	static void setZeroPeriod(uint8_t period_milliseconds);
	static uint8_t available(void);
	static uint8_t getInputNumber(void);
	static uint16_t readValue(void);
	static uint8_t analog2velocity(uint16_t val, uint8_t range);
	static const char *version(void);
};

extern PeakholderClass Peakholder;

