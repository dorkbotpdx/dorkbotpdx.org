#include "WProgram.h"
/* this one is more complicated. It takes the median of the last three adc readings, and averages that. It's a bit smoother and not too much slower. */


void setup();
void loop();
int dOld = 1;
int d = 0;
int bOld = 1;
int b = 0;
long valX[4];
long valY[4];
long valZ[4];
int i = 0;
int av = 16; //sets the number of readings to be averaged
int c=0;

void setup()
{
  Serial.begin(38400);
  pinMode(2, INPUT);
  digitalWrite(2, HIGH);
  pinMode(3, INPUT);
  digitalWrite(3, HIGH);
}  


void loop()
{
  for(i=0;i<av;i++){
    valX[1]=valX[2];
    valX[2]=valX[3];
    valX[3]= analogRead(0);
    valX[0]+=min(max(valX[1], (min(valX[2],valX[3]))),max(valX[2],valX[3]));



    valY[1]=valY[2];
    valY[2]=valY[3];
    valY[3]= analogRead(1);
    valY[0]+=min(max(valY[1], (min(valY[2],valY[3]))),max(valY[2],valY[3]));

    valZ[1]=valZ[2];
    valZ[2]=valZ[3];
    valZ[3]= analogRead(2);
    valZ[0]+=min(max(valZ[1], (min(valZ[2],valZ[3]))),max(valZ[2],valZ[3]));
  }



  Serial.print("c ");
  Serial.println(c);
  c++;

  Serial.print("x ");
  Serial.println(valX[0]/av);

  Serial.print("y ");
  Serial.println(valY[0]/av);

  Serial.print("z ");
  Serial.println(valZ[0]/av);


  valX[0] = 0;
  valY[0] = 0;
  valZ[0] = 0;

  b=digitalRead(2);
  if(bOld != b)
  {
    Serial.print("b ");
    Serial.println(b);
    bOld = b;
  }

  d=digitalRead(3);
  if(dOld != d)
  {
    Serial.print("d ");
    Serial.println(d);
    dOld = d;
  }  
  
  //delay(100);
}

int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

