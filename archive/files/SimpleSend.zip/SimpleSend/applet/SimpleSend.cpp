#include "WProgram.h"


/* how to send data from arduino to Pd, without over-thinking. 
 Includes a "for" loop for averaging adc readings, 
 and a condition that will only send the digital pins if they change. */


void setup();
void loop();
int b, d = 1;         //buttons
int bOld, dOld = 0;
int valX, valY, valZ = 0; //knobs
// int valW = 0;
//int i = 0;
int av = 16; //sets the number of readings to be averaged. Around 30 there is a risk of overrunning the "int" type.
int c = 0;          //counter

void setup()
{
  Serial.begin(38400);	// opens serial port, sets data rate to 38400 bps
  pinMode(2, INPUT);
  digitalWrite(2, HIGH);
  pinMode(3, INPUT);
  digitalWrite(3, HIGH);
}  

void loop()
{
  for(int i=0; i<av; i++)
  {
    //    valW += analogRead(3);
    valX += analogRead(0);
    valY += analogRead(1);
    valZ += analogRead(2);
  }

  Serial.print("c ");
  Serial.println(c);

  c++;                //increment the timer
  if(c>=10000) c=0;  //my Pd patch can't handle numbers over 9999, so i reset.

  //  Serial.print("w ");
  //  Serial.println(valW/av);

  Serial.print("x ");
  Serial.println(valX/av);


  Serial.print("y ");
  Serial.println(valY/av);

  Serial.print("z ");
  Serial.println(valZ/av);

  // valW = 0;
  valX = 0;
  valY = 0;
  valZ = 0;

  b=digitalRead(2);
  if(b != bOld)
  {
    Serial.print("b ");
    Serial.println(b);
    bOld = b;
  }

  d=digitalRead(3);
  if(d != dOld)
  {
    Serial.print("d ");
    Serial.println(d);
    bOld = b;
  }
  //  delay(200);
}

int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

