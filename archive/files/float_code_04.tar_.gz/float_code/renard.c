#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdint.h>
#include <util/delay.h>

#include "renard.h"
#include "serial.h"
#include "print.h"
#include "pins.h"
#include "address.h"

uint8_t renard2intensity(uint8_t b)
{
	if (b < 28) return 0;
	if (b < 57) return 1;
	if (b < 85) return 2;
	if (b < 113) return 3;
	if (b < 142) return 4;
	if (b < 171) return 5;
	if (b < 199) return 6;
	if (b < 228) return 7;
	return 8;
}

// Communication protocol:
// http://www.doityourselfchristmas.com/wiki/index.php?title=Renard
// http://doityourselfchristmas.com/forums/showthread.php?5110-Renard-Protocol-Definition

#define RENARD_IGNORE	0
#define RENARD_ADDRESS	1
#define RENARD_DATA	2
#define RENARD_ESC	128

// if the value 0x7E needs to be transmitted, it is encoded as the
// pair '0x7F,0x31', and 0x7F is encoded as the pair '0x7F,0x30'

void renard(uint8_t b, uint8_t myaddr)
{
	static uint8_t parse_state=0;
	static uint16_t data_index=0;
	uint16_t myindex;

	if (b == 0x7D) {
		return;		// ignore pad bytes
	}
	if (b == 0x7F) {
		parse_state |= RENARD_ESC;
		return;
	}
	if (b == 0x7E) {
		parse_state = RENARD_ADDRESS;
		return;
	}
	if (parse_state & RENARD_ESC) {
		switch (b) {
		  // esc decoding not well specified in protocol spec
		  case 0x30: b = 0x7F; break;
		  case 0x31: b = 0x7E; break;
		  case 0x32: b = 0x7D; break;
		  default: b = 0;
		}
		parse_state &= ~RENARD_ESC;
	}

	switch (parse_state) {
	  case RENARD_IGNORE:
		break;
	  case RENARD_ADDRESS:
		if (b >= 0x80) {
			data_index = ((uint16_t)(b - 0x80)) << 3;
			parse_state = RENARD_DATA;
		} else {
			parse_state = RENARD_IGNORE;
		}
		break;
	  case RENARD_DATA:
		if (myaddr >= 1) {
			myindex = ((uint16_t)(myaddr - 1)) << 3;
			if (data_index >= myindex && data_index < myindex + 8) {
				intensity[data_index - myindex] = renard2intensity(b);
			}
			data_index++;
		}
	}
}

