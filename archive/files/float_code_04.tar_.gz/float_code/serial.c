#include <avr/io.h>
#include <avr/interrupt.h>
#include <inttypes.h>

#include "serial.h"

#define RX_BUFFER_SIZE 64
static volatile uint8_t rx_buffer[RX_BUFFER_SIZE];
static volatile uint8_t rx_buffer_head = 0;
static volatile uint8_t rx_buffer_tail = 0;

#define TX_BUFFER_SIZE 40
static volatile uint8_t tx_buffer[TX_BUFFER_SIZE];
static volatile uint8_t tx_buffer_head = 0;
static volatile uint8_t tx_buffer_tail = 0;
static volatile uint8_t transmitting = 0;

void serial_begin2(uint16_t baud_count)
{
#if 0
	if ((baud_count & 1) && baud_count <= 4096) {
		UCSR0A = (1<<U2X0);
		UBRR0 = baud_count - 1;
	} else {
		UCSR0A = 0;
		UBRR0 = (baud_count >> 1) - 1;
	}
	if (!(UCSR0B & (1<<TXEN0))) {
		rx_buffer_head = 0;
		rx_buffer_tail = 0;
		tx_buffer_head = 0;
		tx_buffer_tail = 0;
		transmitting = 0;
		UCSR0C = (1<<UCSZ01) | (1<<UCSZ00);
		UCSR0B = (1<<RXEN0) | (1<<TXCIE0) | (1<<TXEN0) | (1<<RXCIE0);
	}
#endif
	UCSR0A = (1<<U2X0);
	UBRR0 = baud_count - 1;
	UCSR0B = (1<<RXEN0) | (1<<TXEN0);
}

int serial_available(void)
{
#if 0
	uint8_t head, tail;

	head = rx_buffer_head;
	tail = rx_buffer_tail;
	if (head >= tail) return head - tail;
	return RX_BUFFER_SIZE + head - tail;
#endif
	if (UCSR0A & (1<<RXC0)) return 1;
	return 0;
}

int serial_read(void)
{
#if 0
	uint8_t c, i;

	if (rx_buffer_head == rx_buffer_tail) return -1;
	i = rx_buffer_tail + 1;
	if (i >= RX_BUFFER_SIZE) i = 0;
	c = rx_buffer[i];
	rx_buffer_tail = i;
	return c;
#endif
	if (UCSR0A & (1<<RXC0)) return UDR0;
	return -1;
}

void serial_write(uint8_t c)
{
#if 0
	uint8_t i;

	if (!(UCSR0B & (1<<TXEN0))) return;
	i = tx_buffer_head + 1;
	if (i >= TX_BUFFER_SIZE) i = 0;
	while (tx_buffer_tail == i) ; // wait until space in buffer
	tx_buffer[i] = c;
	transmitting = 1;
	tx_buffer_head = i;
	UCSR0B = (1<<RXEN0) | (1<<TXCIE0) | (1<<TXEN0) | (1<<RXCIE0) | (1<<UDRIE0);
#endif
	while (!(UCSR0A & (1<<UDRE0)));
	UCSR0A |= (1<<TXC0);
	UDR0 = c;
}

#if 0
ISR(USART_RX_vect)
{
	uint8_t c, i;

	c = UDR0;
	i = rx_buffer_head + 1;
	if (i >= RX_BUFFER_SIZE) i = 0;
	if (i != rx_buffer_tail) {
		rx_buffer[i] = c;
		rx_buffer_head = i;
	}
}

ISR(USART_UDRE_vect)
{
	uint8_t i;

	if (tx_buffer_head == tx_buffer_tail) {
		// buffer is empty, disable transmit interrupt
		UCSR0B = (1<<RXEN0) | (1<<TXCIE0) | (1<<TXEN0) | (1<<RXCIE0);
	} else {
		i = tx_buffer_tail + 1;
		if (i >= TX_BUFFER_SIZE) i = 0;
		UDR0 = tx_buffer[i];
		tx_buffer_tail = i;
	}
}

ISR(USART_TX_vect)
{
	transmitting = 0;
}
#endif

