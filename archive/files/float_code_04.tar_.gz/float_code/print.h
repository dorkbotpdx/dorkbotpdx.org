#ifndef print_h__
#define print_h__

#include <avr/pgmspace.h>
#include "serial.h"

// this macro allows you to write print("some text") and
// the string is automatically placed into flash memory :)
#define print(s) print_P(PSTR(s))
#define pchar(c) serial_write(c)

void print_P(const char *s);
void phex(unsigned char c);
void phex16(unsigned int i);
void phex32(unsigned long i);

#endif
