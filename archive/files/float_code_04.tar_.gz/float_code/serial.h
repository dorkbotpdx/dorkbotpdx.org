#ifndef serial_h_
#define serial_h_

#include <stdint.h>

void serial_begin2(uint16_t baud_count);
static inline void serial_begin(uint32_t baud);
static inline void serial_begin(uint32_t baud) {
	serial_begin2(((F_CPU / 8) + (baud / 2)) / baud);
}
int serial_available(void);
int serial_read(void);
void serial_write(uint8_t c);

#endif
