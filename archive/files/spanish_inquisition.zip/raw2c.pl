#! /usr/bin/perl

binmode IN, ":bytes";
$file = $ARGV[0];

foreach $file (@ARGV) {
	open(IN, $file) or die "Can't open $file: $!\n";
	$count = 0;
	$len = -s $file;
	$file =~ /^([-_A-Za-z0-9\/]+)/;
	$name = "file_$1";
	$name =~ s/\//_/g;
	$name =~ s/-/_/g;
	$size[$numfiles] = $len;
	$list[$numfiles++] = $name;
	print "static const unsigned char ${name}[$len] = \{\n";
	while (read(IN, $byte, 1) == 1) {
		$n = ord($byte);
		printf '0x%02X', $n;
		print ',' if $count < $len - 1;
		print "\n" if $count++ % 12 == 11;
	}
	print "\};\n";
	close(IN);
}
exit;


