#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdint.h>
#include <util/delay.h>

#include "midi.h"
#include "serial.h"
#include "print.h"
#include "pins.h"
#include "address.h"

uint8_t midi2intensity(uint8_t velocity)
{
	if (velocity < 6) return 0;
	if (velocity < 12) return 1;
	if (velocity < 18) return 2;
	if (velocity < 24) return 3;
	if (velocity < 30) return 4;
	if (velocity < 36) return 5;
	if (velocity < 42) return 6;
	if (velocity < 48) return 7;
/*
	if (velocity < 14) return 0;
	if (velocity < 28) return 1;
	if (velocity < 42) return 2;
	if (velocity < 56) return 3;
	if (velocity < 70) return 4;
	if (velocity < 84) return 5;
	if (velocity < 98) return 6;
	if (velocity < 112) return 7;
*/
	return 8;
}

#define MIDI_MY_CHANNEL		0

#define MIDI_IGNORE		0
#define MIDI_COMMAND		1
#define MIDI_NOTEON		2
#define MIDI_NOTEON_VELOCITY	3
#define MIDI_NOTEOFF		4
#define MIDI_NOTEOFF_VELOCITY	5


void midi(uint8_t b, uint8_t myaddr)
{
	static uint8_t parse_state=MIDI_IGNORE;
	static uint8_t note=0;
	uint8_t myindex;

	if (myaddr < 1 || myaddr > 15) return;
	myindex = (myaddr - 1) << 3;
	if (b & 0x80) parse_state = MIDI_COMMAND;

	switch (parse_state) {
	  case MIDI_COMMAND:
		if (((b & 0xF0) == 0x90) && ((b & 0x0F) == MIDI_MY_CHANNEL)) {
			parse_state = MIDI_NOTEON;
			break;
		}
		if (((b & 0xF0) == 0x80) && ((b & 0x0F) == MIDI_MY_CHANNEL)) {
			parse_state = MIDI_NOTEOFF;
			break;
		}
		parse_state = MIDI_IGNORE;
		break;

	  case MIDI_NOTEON:
		note = b;
		parse_state = MIDI_NOTEON_VELOCITY;
		break;

	  case MIDI_NOTEON_VELOCITY:
		if (note >= myindex && note <= myindex + 7) {
			intensity[note - myindex] = midi2intensity(b);
		}
		parse_state = MIDI_NOTEON;
		break;

	  case MIDI_NOTEOFF:
		note = b;
		parse_state = MIDI_NOTEOFF_VELOCITY;
		break;

	  case MIDI_NOTEOFF_VELOCITY:
		if (note >= myindex && note <= myindex + 7) {
			intensity[note - myindex] = 0;
		}
		parse_state = MIDI_NOTEOFF;
		break;
	}
}

