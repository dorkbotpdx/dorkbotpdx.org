#include <stdint.h>

#include "serial.h"
#include "print.h"
#include "pins.h"

#define DELAY8() asm volatile("nop\t\nnop\t\nnop\t\nnop\t\nnop\t\nnop\t\nnop\t\nnop\n")

uint8_t jumpers(void)
{
	uint8_t val = 0, tmp = 0;

	// configure all as inputs with pullups
	JUMPER0_IN_PULLUP();
	JUMPER1_IN_PULLUP();
	JUMPER2_IN_PULLUP();
	JUMPER3_IN_PULLUP();
	JUMPER4_IN_PULLUP();
	JUMPER5_IN_PULLUP();
	DELAY8();

	// is jumper0 shorted to ground ?
	if (JUMPER0_READ() == 0) val |= 1;

	// is jumper1 shorted to jumper0 ?
	JUMPER0_OUT_LOW();
	DELAY8();
	if (JUMPER1_READ() == 0) val |= 2;
	JUMPER0_IN_PULLUP();

	// is jumper2 shorted to jumper1 ?
	JUMPER1_OUT_LOW();
	DELAY8();
	if (JUMPER2_READ() == 0) val |= 4;
	JUMPER1_IN_PULLUP();

	// is jumper3 shorted to jumper2 or jumper4 ?
	// jumper3 has a LED connected, so we can not read
	// it reliably... it must drive both high and low
	// and be read by its adjacent pins
	JUMPER3_OUT_LOW();
	DELAY8();
	if (JUMPER2_READ() == 0) tmp |= 8;
	if (JUMPER4_READ() == 0) tmp |= 16;
	JUMPER3_OUT_HIGH();
	DELAY8();
	if ((tmp & 8) && JUMPER2_READ() == 1) val |= 8;
	if ((tmp & 16) && JUMPER4_READ() == 1) val |= 16;
	JUMPER3_IN_PULLUP();

	// is jumper4 shorted to jumper5 ?
	JUMPER4_OUT_LOW();
	DELAY8();
	if (JUMPER5_READ() == 0) val |= 32;
	JUMPER4_IN_PULLUP();

	//print("jumpers: ");
	//phex(val);
	//print(", ");
	//print("\n");
	return val;
}

uint8_t address(void)
{
	switch (jumpers()) {
	  case 0x01: return 1;
	  case 0x02: return 2;
	  case 0x04: return 3;
	  case 0x08: return 4;
	  case 0x10: return 5;
	  case 0x20: return 6;
	  case 0x05: return 7;
	  case 0x0A: return 8;
	  case 0x14: return 9;
	  case 0x28: return 10;
	  case 0x09: return 11;
	  case 0x12: return 12;
	  case 0x24: return 13;
	  case 0x11: return 14;
	  case 0x22: return 15;
	  default: return 0;
	}
}

