#ifndef pins_h__
#define pins_h__

#define DEFAULT_PORTC   0xFF
#define DEFAULT_DDRC    0x00
#define DEFAULT_PORTD   0x02
#define DEFAULT_DDRD    0xFE
#define DEFAULT_PORTB   0x3C
#define DEFAULT_DDRB    0xC3

#define LED_ON()        (PORTB |= (1 << 5), DDRB |= (1 << 5))
#define LED_OFF()       (PORTB &= ~(1 << 5), DDRB |= (1 << 5))

#define EL_A_ON()	(PORTD |= (1 << 2))
#define EL_A_OFF()	(PORTD &= ~(1 << 2))
#define EL_B_ON()	(PORTD |= (1 << 3))
#define EL_B_OFF()	(PORTD &= ~(1 << 3))
#define EL_C_ON()	(PORTD |= (1 << 4))
#define EL_C_OFF()	(PORTD &= ~(1 << 4))
#define EL_D_ON()	(PORTD |= (1 << 5))
#define EL_D_OFF()	(PORTD &= ~(1 << 5))
#define EL_E_ON()	(PORTD |= (1 << 6))
#define EL_E_OFF()	(PORTD &= ~(1 << 6))
#define EL_F_ON()	(PORTD |= (1 << 7))
#define EL_F_OFF()	(PORTD &= ~(1 << 7))
#define EL_G_ON()	(PORTB |= (1 << 0))
#define EL_G_OFF()	(PORTB &= ~(1 << 0))
#define EL_H_ON()	(PORTB |= (1 << 1))
#define EL_H_OFF()	(PORTB &= ~(1 << 1))

#define JUMPER0_OUT_LOW()	(PORTC &= ~(1 << 0), DDRC |= (1 << 0))
#define JUMPER0_OUT_HIGH()	(PORTC |= (1 << 0), DDRC |= (1 << 0))
#define JUMPER0_IN_PULLUP()	(DDRC &= ~(1 << 0), PORTC |= (1 << 0))
#define JUMPER0_READ()		((PINC & (1 << 0)) ? 1 : 0)

#define JUMPER1_OUT_LOW()	(PORTB &= ~(1 << 4), DDRB |= (1 << 4))
#define JUMPER1_OUT_HIGH()	(PORTB |= (1 << 4), DDRB |= (1 << 4))
#define JUMPER1_IN_PULLUP()	(DDRB &= ~(1 << 4), PORTB |= (1 << 4))
#define JUMPER1_READ()		((PINB & (1 << 4)) ? 1 : 0)

#define JUMPER2_OUT_LOW()	(PORTB &= ~(1 << 3), DDRB |= (1 << 3))
#define JUMPER2_OUT_HIGH()	(PORTB |= (1 << 3), DDRB |= (1 << 3))
#define JUMPER2_IN_PULLUP()	(DDRB &= ~(1 << 3), PORTB |= (1 << 3))
#define JUMPER2_READ()		((PINB & (1 << 3)) ? 1 : 0)

#define JUMPER3_OUT_LOW()	(PORTB &= ~(1 << 5), DDRB |= (1 << 5))
#define JUMPER3_OUT_HIGH()	(PORTB |= (1 << 5), DDRB |= (1 << 5))
#define JUMPER3_IN_PULLUP()	(DDRB &= ~(1 << 5), PORTB |= (1 << 5))
#define JUMPER3_READ()		((PINB & (1 << 5)) ? 1 : 0)

#define JUMPER4_OUT_LOW()	(PORTB &= ~(1 << 2), DDRB |= (1 << 2))
#define JUMPER4_OUT_HIGH()	(PORTB |= (1 << 2), DDRB |= (1 << 2))
#define JUMPER4_IN_PULLUP()	(DDRB &= ~(1 << 2), PORTB |= (1 << 2))
#define JUMPER4_READ()		((PINB & (1 << 2)) ? 1 : 0)

#define JUMPER5_OUT_LOW()	(PORTC &= ~(1 << 1), DDRC |= (1 << 1))
#define JUMPER5_OUT_HIGH()	(PORTC |= (1 << 1), DDRC |= (1 << 1))
#define JUMPER5_IN_PULLUP()	(DDRC &= ~(1 << 1), PORTC |= (1 << 1))
#define JUMPER5_READ()		((PINC & (1 << 1)) ? 1 : 0)

static inline void pins_init(void);
static inline void pins_init(void) {
	PORTC = DEFAULT_PORTC;
	PORTD = DEFAULT_PORTD;
	PORTB = DEFAULT_PORTB;
	DDRC = DEFAULT_DDRC;
	DDRD = DEFAULT_DDRD;
	DDRB = DEFAULT_DDRB;
}

void pin_write(uint8_t pin, uint8_t val);

#endif
