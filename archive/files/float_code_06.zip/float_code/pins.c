#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdint.h>
#include <util/delay.h>

#include "pins.h"

void pin_write(uint8_t pin, uint8_t val)
{
	if (val) {
		switch (pin) {
		  case 0: EL_A_ON(); return;
		  case 1: EL_B_ON(); return;
		  case 2: EL_C_ON(); return;
		  case 3: EL_D_ON(); return;
		  case 4: EL_E_ON(); return;
		  case 5: EL_F_ON(); return;
		  case 6: EL_G_ON(); return;
		  case 7: EL_H_ON(); return;
		  default: return;
		}
	} else {
		switch (pin) {
		  case 0: EL_A_OFF(); return;
		  case 1: EL_B_OFF(); return;
		  case 2: EL_C_OFF(); return;
		  case 3: EL_D_OFF(); return;
		  case 4: EL_E_OFF(); return;
		  case 5: EL_F_OFF(); return;
		  case 6: EL_G_OFF(); return;
		  case 7: EL_H_OFF(); return;
		  default: return;
		}
	}
}

