#ifndef renard_h_
#define renard_h_

#include <stdint.h>

void renard(uint8_t b, uint8_t myaddr);

extern uint8_t intensity[8];

#endif
