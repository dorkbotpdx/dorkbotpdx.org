#ifndef midi_h_
#define midi_h_

#include <stdint.h>

void midi(uint8_t b, uint8_t myaddr);

extern uint8_t intensity[8];

#endif
