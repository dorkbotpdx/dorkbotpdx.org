#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdint.h>
#include <util/delay.h>

#include "serial.h"
#include "print.h"
#include "pins.h"
#include "address.h"
#include "renard.h"
#include "midi.h"


uint8_t intensity[8];

const uint8_t bitmaps[9] = {
	0b00000000,  // 0
	0b10000000,  // 1
	0b10001000,  // 2
	0b10010010,  // 3
	0b10101010,  // 4
	0b01101101,  // 5
	0b01110111,  // 6
	0b01111111,  // 7
	0b11111111   // 8
};

void update(uint8_t state)
{
	uint8_t i, val;

	state &= 7;
	for (i=0; i<8; i++) {
		val = intensity[i];
		if (val > 8) val = 8;
		pin_write(i, (bitmaps[val] ^ 0xFF) & (1 << ((state + i) & 7)));
	}
}


int main(void)
{
	uint8_t addr, count=0, state=0;
	int i;

	pins_init();
	serial_begin(31250);
	//serial_begin(19200);
	//print("\nEl Wire Project\n");
	TCCR0A = 0x02;	// mode 2, CTC
	TCCR0B = 0x04;	// prescaler = 256
	//OCR0A = 156;	// approx 200 Hz
	OCR0A = 78;	// approx 400 Hz
	addr = address();
	for (i=0; i<8; i++) {
		intensity[i] = 0;
		//intensity[i] = i + 1;
		//intensity[i] = 8;
	}

	while (1) {
		if (TIFR0 & (1 << OCF0A)) {
			TIFR0 = (1 << OCF0A);
			update(state++);
			if (count++ == 0) addr = address();
		}
		i = serial_read();
		if (i >= 0) midi(i, addr);
		//if (i >= 0) renard(i, addr);
	}
}


